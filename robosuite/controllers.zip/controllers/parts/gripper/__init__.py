from .simple_grip import SimpleGripController
